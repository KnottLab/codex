function [dataOut,errSurfaceMin,errSurface] = shading_correction_BBC_gpu(I)

I = gpuArray(I);

numScales = 50;
stopCriterion = 0.05;

[rows,cols] = size(I);
I = double(I);

% I1 = gpuArray(gaussian_smoothing(I,3,1));
I1 = gaussian_smoothing(I,3,1);
% I1 = imgaussfilt(I,1,'FilterSize',3);
% I = gather(I);

yMin = I1;

tot_grad_min1 = zeros(numScales/2,1,'gpuArray');

for i = 1:2:numScales
    
    disp(['shading correction: ',num2str(round(100*i/numScales)),'%'])

    tempAvMin = (I1(1:end-2*i,1+2*i:end)+I1(1+2*i:end,1:end-2*i))/2;
    tempAvMin = min(tempAvMin,(I1(1:end-2*i,1:end-2*i)+I1(1+2*i:end,1+2*i:end))/2);
    tempAvMin = min(tempAvMin,(I1(1:end-2*i,1+i:end-i)+I1(1+2*i:end,1+i:end-i))/2);
    tempAvMin = min(tempAvMin,(I1(1+i:end-i,1:end-2*i)+I1(1+i:end-i,1+2*i:end))/2);

    yMin(1+i:rows-i,1+i:cols-i) = min(yMin(1+i:rows-i,1+i:cols-i),tempAvMin);
    clear tempAvMin
    
    yMin2 = gaussian_smoothing(yMin,i,2);
%     yMin2 = gpuArray(gaussian_smoothing(gather(yMin),i,2));

    y_rderiv_Min = diff(yMin2,1,1);
    y_cderiv_Min = diff(yMin2,1,2);
    clear yMin2
    
    tot_grad_min1(i) = sum(sum(sqrt(y_rderiv_Min(:,2:end).^2+y_cderiv_Min(2:end,:).^2)));
    
    if (i>1)
        diffGradMin = abs((tot_grad_min1(end)-tot_grad_min1(end-2))/tot_grad_min1(end-2));
        if (diffGradMin<stopCriterion)
            break;
        end
    end
    
end

errSurfaceMin = gaussian_smoothing(yMin,i,1);
errSurface = (errSurfaceMin);%-mean(errSurfaceMin(:));
dataOut = I - errSurface;

dataOut(dataOut<0) = 0;
dataOut(dataOut>65535) = 65535;
dataOut = uint16(dataOut);

dataOut = gather(dataOut);

end




