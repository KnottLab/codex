function I = apply_shading_correction(I)
tic

[I,~,~] = shading_correction_BBC_cpu(I);

% [I,~,~] = shading_correction_BBC_gpu(I);

% [I,~,~] = shading_correction_BBC_gpu_downsampling(I);

toc 
end